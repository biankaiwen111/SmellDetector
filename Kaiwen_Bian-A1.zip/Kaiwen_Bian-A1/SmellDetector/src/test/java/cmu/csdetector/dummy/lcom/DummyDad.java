package cmu.csdetector.dummy.lcom;

public class DummyDad {
	public int test;
	
	@SuppressWarnings("unused")
	private int privateTest;
	
	public void printTest(){
		System.out.println(test);
	}
}
