package cmu.csdetector.dummy.lcom;

public class DummyGrandSon extends DummySon {
	
	public void printAttributeDad(){
		System.out.println(super.test);
	}

}
