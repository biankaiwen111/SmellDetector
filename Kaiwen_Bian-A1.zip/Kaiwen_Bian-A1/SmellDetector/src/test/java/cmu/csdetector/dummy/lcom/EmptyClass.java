package cmu.csdetector.dummy.lcom;

public class EmptyClass {

}
