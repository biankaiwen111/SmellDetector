package cmu.csdetector.dummy.smells;

public class RefusedBequestSample extends SuperDummy {

	@Override
	protected void a() {
		super.a();
	}

	@Override
	protected void b() {
		super.b();
	}

	@Override
	protected void c() {
		super.c();
	}

	
}
