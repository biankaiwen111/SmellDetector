package cmu.csdetector.dummy.smells;

public abstract class SuperDummy {
	protected String a;
	
	protected void a() {

	}
	
	protected void b() {

	}
	
	protected void c() {

	}
	
	protected void d() {

	}
	
	protected void e() {

	}
}
