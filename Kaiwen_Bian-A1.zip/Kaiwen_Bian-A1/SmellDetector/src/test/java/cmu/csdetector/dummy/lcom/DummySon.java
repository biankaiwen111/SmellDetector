package cmu.csdetector.dummy.lcom;

public class DummySon extends DummyDad {
	
	public void printAttributeDad(){
		System.out.println(test);
	}
	
	public void printHello(){
		System.out.println("Hello");
	}

}
